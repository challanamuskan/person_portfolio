import React, { useState, useRef, useEffect, useCallback } from 'react';
import { GoogleGenAI, Chat, LiveServerMessage, Modality, Blob } from "@google/genai";
import type { ChatMessage } from '../types';

// --- Audio Helper Functions (as per @google/genai guidelines) ---

function encode(bytes: Uint8Array) {
    let binary = '';
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
        binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
}

function decode(base64: string) {
    const binaryString = atob(base64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
}

async function decodeAudioData(
    data: Uint8Array,
    ctx: AudioContext,
    sampleRate: number,
    numChannels: number,
): Promise<AudioBuffer> {
    const dataInt16 = new Int16Array(data.buffer);
    const frameCount = dataInt16.length / numChannels;
    const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

    for (let channel = 0; channel < numChannels; channel++) {
        const channelData = buffer.getChannelData(channel);
        for (let i = 0; i < frameCount; i++) {
            channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
        }
    }
    return buffer;
}


function createBlob(data: Float32Array): Blob {
    const l = data.length;
    const int16 = new Int16Array(l);
    for (let i = 0; i < l; i++) {
        int16[i] = data[i] * 32768;
    }
    return {
        data: encode(new Uint8Array(int16.buffer)),
        mimeType: 'audio/pcm;rate=16000',
    };
}

// Memoized component for individual chat messages to optimize rendering performance.
const ChatMessageBubble = React.memo(({ sender, text }: ChatMessage) => {
    return (
        <div className={`flex ${sender === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-xs md:max-w-sm rounded-lg px-3 py-2 ${sender === 'user' ? 'bg-red-600 text-white' : 'bg-zinc-700'}`}>
                {text}
            </div>
        </div>
    );
});


const Chatbot: React.FC = () => {
    const [isOpen, setIsOpen] = useState(false);
    const [messages, setMessages] = useState<ChatMessage[]>([]);
    const [inputValue, setInputValue] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [isRecording, setIsRecording] = useState(false);
    
    const chatBodyRef = useRef<HTMLDivElement>(null);
    const aiRef = useRef<GoogleGenAI | null>(null);
    const chatRef = useRef<Chat | null>(null);
    const sessionPromiseRef = useRef<Promise<any> | null>(null);
    const audioResourcesRef = useRef<{
      stream: MediaStream | null,
      inputAudioContext: AudioContext | null,
      scriptProcessor: ScriptProcessorNode | null,
      outputAudioContext: AudioContext | null,
      nextStartTime: number,
      sources: Set<AudioBufferSourceNode>,
    } | null>(null);

    const JERRY_SYSTEM_INSTRUCTION = "You are Jerry, a friendly and helpful AI assistant on Muskan Challana's portfolio website. You can answer questions about Muskan, her projects, skills, and education. Keep your answers concise and engaging. Muskan is an AI Generalist and a student at Torrens University, Australia.";

    useEffect(() => {
        if (chatBodyRef.current) {
            chatBodyRef.current.scrollTop = chatBodyRef.current.scrollHeight;
        }
    }, [messages]);

    const initializeApi = useCallback(() => {
        if (!aiRef.current) {
            aiRef.current = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
            chatRef.current = aiRef.current.chats.create({
                model: 'gemini-2.5-flash',
                config: { systemInstruction: JERRY_SYSTEM_INSTRUCTION }
            });
        }
    }, [JERRY_SYSTEM_INSTRUCTION]);

    const handleTextSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!inputValue.trim() || isLoading) return;

        initializeApi();

        const userMessage: ChatMessage = { sender: 'user', text: inputValue };
        setMessages(prev => [...prev, userMessage]);
        setInputValue('');
        setIsLoading(true);

        try {
            if (chatRef.current) {
                const response = await chatRef.current.sendMessage({ message: inputValue });
                const jerryMessage: ChatMessage = { sender: 'jerry', text: response.text };
                setMessages(prev => [...prev, jerryMessage]);
            }
        } catch (error) {
            console.error("Gemini API Error:", error);
            const errorMessage: ChatMessage = { sender: 'jerry', text: "Sorry, I'm having trouble connecting right now." };
            setMessages(prev => [...prev, errorMessage]);
        } finally {
            setIsLoading(false);
        }
    };
    
    const stopVoiceSession = useCallback(() => {
        try {
            if (sessionPromiseRef.current) {
                sessionPromiseRef.current.then(session => session.close());
                sessionPromiseRef.current = null;
            }
            if (audioResourcesRef.current) {
                audioResourcesRef.current.stream?.getTracks().forEach(track => track.stop());
                audioResourcesRef.current.scriptProcessor?.disconnect();
                if (audioResourcesRef.current.inputAudioContext?.state !== 'closed') {
                   audioResourcesRef.current.inputAudioContext?.close();
                }
                if (audioResourcesRef.current.outputAudioContext?.state !== 'closed') {
                   audioResourcesRef.current.outputAudioContext?.close();
                }
                audioResourcesRef.current = null;
            }
        } catch(error) {
            console.error("Error during voice session cleanup:", error);
        } finally {
            setIsRecording(false);
        }
    }, []);

    const handleCloseChat = () => {
        setIsOpen(false);
        stopVoiceSession();
    };

    const handleVoiceToggle = async () => {
        if (isRecording) {
            stopVoiceSession();
            return;
        }

        initializeApi();
        if (!aiRef.current) return;

        try {
            // A more graceful way to handle permissions.
            if (navigator.permissions) {
                const permissionStatus = await navigator.permissions.query({ name: 'microphone' as PermissionName });
                if (permissionStatus.state === 'denied') {
                    setMessages(prev => [...prev, { sender: 'jerry', text: "I can't access your microphone. Please enable it in your browser settings to use voice chat." }]);
                    return;
                }
            }
            
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            setIsRecording(true);

            let currentInputTranscription = '';
            let currentOutputTranscription = '';

            const inputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
            const outputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
            const outputNode = outputAudioContext.createGain();
            outputNode.connect(outputAudioContext.destination);

            audioResourcesRef.current = {
                stream,
                inputAudioContext,
                scriptProcessor: null,
                outputAudioContext,
                nextStartTime: 0,
                sources: new Set(),
            };
            
            sessionPromiseRef.current = aiRef.current.live.connect({
                model: 'gemini-2.5-flash-native-audio-preview-09-2025',
                callbacks: {
                    onopen: () => {
                        const source = inputAudioContext.createMediaStreamSource(stream);
                        const scriptProcessor = inputAudioContext.createScriptProcessor(4096, 1, 1);
                        audioResourcesRef.current!.scriptProcessor = scriptProcessor;
                        
                        scriptProcessor.onaudioprocess = (audioProcessingEvent) => {
                            const inputData = audioProcessingEvent.inputBuffer.getChannelData(0);
                            const pcmBlob = createBlob(inputData);
                            sessionPromiseRef.current?.then((session) => {
                                session.sendRealtimeInput({ media: pcmBlob });
                            });
                        };
                        source.connect(scriptProcessor);
                        // Connect to a muted GainNode to enable processing without audible feedback
                        const gainNode = inputAudioContext.createGain();
                        gainNode.gain.setValueAtTime(0, inputAudioContext.currentTime);
                        scriptProcessor.connect(gainNode);
                        gainNode.connect(inputAudioContext.destination);
                    },
                    onmessage: async (message: LiveServerMessage) => {
                        if (message.serverContent?.inputTranscription) {
                            currentInputTranscription += message.serverContent.inputTranscription.text;
                        }
                        if (message.serverContent?.outputTranscription) {
                            currentOutputTranscription += message.serverContent.outputTranscription.text;
                        }
                        if (message.serverContent?.turnComplete) {
                            if(currentInputTranscription.trim()){
                                setMessages(prev => [...prev, { sender: 'user', text: currentInputTranscription }]);
                            }
                             if(currentOutputTranscription.trim()){
                                setMessages(prev => [...prev, { sender: 'jerry', text: currentOutputTranscription }]);
                            }
                            currentInputTranscription = '';
                            currentOutputTranscription = '';
                        }
                        const audioData = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
                        if (audioData) {
                             const res = audioResourcesRef.current;
                             if(!res) return;
                             res.nextStartTime = Math.max(res.nextStartTime, res.outputAudioContext.currentTime);
                             const audioBuffer = await decodeAudioData(decode(audioData), res.outputAudioContext, 24000, 1);
                             const source = res.outputAudioContext.createBufferSource();
                             source.buffer = audioBuffer;
                             source.connect(outputNode);
                             source.addEventListener('ended', () => res.sources.delete(source));
                             source.start(res.nextStartTime);
                             res.nextStartTime += audioBuffer.duration;
                             res.sources.add(source);
                        }
                        const interrupted = message.serverContent?.interrupted;
                        if (interrupted) {
                            const res = audioResourcesRef.current;
                            if (res) {
                                for (const source of res.sources.values()) {
                                    source.stop();
                                    res.sources.delete(source);
                                }
                                res.nextStartTime = 0;
                            }
                        }
                    },
                    onerror: (e: ErrorEvent) => {
                        console.error('Live session error:', e);
                        setMessages(prev => [...prev, { sender: 'jerry', text: "Sorry, there was a connection error during our voice chat." }]);
                        stopVoiceSession();
                    },
                    onclose: (e: CloseEvent) => {
                         stopVoiceSession();
                    },
                },
                config: {
                    responseModalities: [Modality.AUDIO],
                    speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } } },
                    systemInstruction: JERRY_SYSTEM_INSTRUCTION,
                    inputAudioTranscription: {},
                    outputAudioTranscription: {},
                },
            });

        } catch (err) {
            console.error("Microphone access denied:", err);
            setMessages(prev => [...prev, { sender: 'jerry', text: "I couldn't access your microphone. Please grant permission to use the voice feature." }]);
            setIsRecording(false);
        }
    };

    return (
      <>
        <div className={`fixed bottom-0 left-0 m-5 transition-all duration-300 z-[60] ${isOpen ? 'translate-y-20 opacity-0' : 'translate-y-0 opacity-100'}`}>
            <button onClick={() => setIsOpen(true)} className="bg-red-600 text-white rounded-full p-4 shadow-lg hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-opacity-50">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M18 10c0 3.866-3.582 7-8 7a8.894 8.894 0 01-4.22-1.22l-1.854.618a.5.5 0 01-.622-.622l.618-1.854A8.894 8.894 0 012 10c0-3.866 3.582-7 8-7s8 3.134 8 7zM4.415 14.167l1.32.44a6.973 6.973 0 003.821 1.383A7.005 7.005 0 0018 10a5.005 5.005 0 00-5-5c-2.43 0-4.453 1.714-4.898 3.967a.5.5 0 01-.98.196A6.97 6.97 0 014 10c0 .841.15 1.65.415 2.392L3.13 15.87l1.285-1.703z" clipRule="evenodd" /></svg>
            </button>
        </div>

        <div className={`fixed bottom-0 left-0 m-5 w-[calc(100%-40px)] md:w-96 h-[70vh] bg-zinc-900 rounded-xl shadow-2xl flex flex-col transition-transform duration-500 ease-in-out z-[60] ${isOpen ? 'transform translate-y-0' : 'transform translate-y-[110%]'}`}>
            <div className="flex justify-between items-center p-4 border-b border-zinc-700">
                <h3 className="text-lg font-bold">Chat with Jerry</h3>
                <button onClick={handleCloseChat} className="text-gray-400 hover:text-white">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                </button>
            </div>
            <div ref={chatBodyRef} className="flex-1 p-4 overflow-y-auto space-y-4">
                {messages.map((msg, index) => (
                    <ChatMessageBubble key={index} sender={msg.sender} text={msg.text} />
                ))}
                {isLoading && <div className="flex justify-start"><div className="bg-zinc-700 rounded-lg px-3 py-2">...</div></div>}
            </div>
            <div className="p-4 border-t border-zinc-700">
                <form onSubmit={handleTextSubmit} className="flex items-center space-x-2">
                    <input type="text" value={inputValue} onChange={(e) => setInputValue(e.target.value)} placeholder="Type a message..." className="flex-1 bg-zinc-800 rounded-full px-4 py-2 focus:outline-none focus:ring-2 focus:ring-red-500" disabled={isRecording}/>
                    <button type="button" onClick={handleVoiceToggle} className={`p-2 rounded-full transition-colors ${isRecording ? 'bg-red-700 text-white animate-pulse' : 'bg-zinc-700 text-gray-300 hover:bg-zinc-600'}`}>
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M7 4a3 3 0 016 0v4a3 3 0 11-6 0V4zm4 10.93A7.001 7.001 0 0017 8a1 1 0 10-2 0A5 5 0 015 8a1 1 0 00-2 0 7.001 7.001 0 006 6.93V17H6a1 1 0 100 2h8a1 1 0 100-2h-3v-2.07z" clipRule="evenodd" /></svg>
                    </button>
                    <button type="submit" className="bg-red-600 text-white rounded-full p-2 hover:bg-red-700 disabled:bg-gray-500" disabled={!inputValue.trim() || isLoading || isRecording}>
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
                    </button>
                </form>
            </div>
        </div>
      </>
    );
};

export default Chatbot;