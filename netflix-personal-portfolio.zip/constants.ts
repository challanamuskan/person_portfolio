import { ContentCategory } from './types';

export const PERSONAL_INFO = {
    name: 'Muskan Challana',
    title: 'Business Information Systems | AI Generalist',
    bio: "I'm a driven Torrens University undergraduate pursuing a Bachelor of Business Information Systems, fuelled by 2.5 years of retail experience where I turned data into action, boosting sales by 15% through creative problem-solving. With skills in Python, R, Excel, SQL, and AI, I thrive on tackling tough business puzzles and delivering insights that shape decisions.",
    resumeUrl: '#', // Add a link to your downloadable resume PDF here
    contactEmail: 'mailto:cmuskan009@gmail.com',
    socials: {
        linkedin: "https://www.linkedin.com/in/muskan-challana-408234163/",
        github: "https://github.com/challanamuskan", // Assuming this is your GitHub, replace if not
        instagram: "https://www.instagram.com/muskanchallana",
        facebook: "https://www.facebook.com/share/17J6tNCTvP/?mibextid=wwXIfr"
    }
};

export const PORTFOLIO_DATA: ContentCategory[] = [
    {
        title: "Professional Experience",
        items: [
            {
                id: 1,
                title: "Sales & Marketing Coordinator",
                description: "Lagardère AWPL | June 2022 - June 2024",
                longDescription: "Transformed daily customer data into actionable Excel insights, launching promotions that lifted repeat visits and sales by 15%. Single-handedly optimized inventory with pivot tables and formulas, cutting stock variances by 22%. Crafted tailored pitches for luxury buyers and hurried travellers, boosting upsell rates by 20%. Built weekly Google Sheets dashboards to share real-time insights with a 3-person team.",
                imageUrl: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?q=80&w=2071&auto=format&fit=crop",
                tags: ["Data Analysis", "Excel", "Inventory Management", "Sales Strategy"],
                year: "2022-2024",
            },
            {
                id: 2,
                title: "Seasonal Product Promoter",
                description: "Costco Wholesale | Jan 2024 - April 2024",
                longDescription: "Chatted with customers on the floor to understand their spending habits, refining pitches on the fly to exceed sales quotas by 12% during a hectic holiday rush. Teamed up with 4-6 colleagues to track stock and prioritize tasks using Excel templates, adapting layouts mid-shift to keep operations smooth under pressure.",
                imageUrl: "https://images.unsplash.com/photo-1556742111-a3297a0e5d52?q=80&w=2070&auto=format&fit=crop",
                tags: ["Sales", "Customer Relations", "Excel", "Teamwork"],
                year: "2024",
            },
            {
                id: 3,
                title: "Sales Representative",
                description: "Nespresso Boutique | Jan 2023 - July 2023",
                longDescription: "Gleaned insights from 100+ daily demos, weaving personalized stories that lifted conversion rates by 25%. Created Excel trackers for transactions and inventory, independently crafting monthly reports that guided store decisions and streamlined solo closing shifts.",
                imageUrl: "https://images.unsplash.com/photo-1580920469275-653531b36965?q=80&w=2070&auto=format&fit=crop",
                tags: ["Customer Insights", "Sales Conversion", "Excel", "Reporting"],
                year: "2023",
            },
        ]
    },
    {
        title: "Volunteering",
        items: [
            {
                id: 27,
                title: "University Mentor",
                description: "University of South Australia | 2022-2024",
                longDescription: "Mentored students for 2 years (2022–2024), guiding them through academic challenges and the transition to university life, fostering a supportive and successful learning environment.",
                imageUrl: "https://images.unsplash.com/photo-1543269865-cbf427effbad?q=80&w=2070&auto=format&fit=crop",
                tags: ["Mentoring", "UniSA", "Student Support", "Guidance"],
                year: "2022-2024",
            },
            {
                id: 28,
                title: "Community Caregiver",
                description: "NDIS & Lutheran Care, Adelaide",
                longDescription: "Provided compassionate support and care for aged care residents and individuals with disabilities for over a year, assisting with daily activities and enhancing their quality of life.",
                imageUrl: "https://images.unsplash.com/photo-1583912267677-474718524c2f?q=80&w=1974&auto=format&fit=crop",
                tags: ["Community Support", "Aged Care", "Disability Support", "NDIS"],
                year: "2021-2022",
            },
            {
                id: 29,
                title: "COVID Concierge",
                description: "Flinders Hospital, Adelaide",
                longDescription: "Served as a COVID Concierge at a major hospital, assisting with patient admissions, providing clear information, and ensuring a safe and orderly process for both hospital and COVID patients during a critical time.",
                imageUrl: "https://images.unsplash.com/photo-1580281658223-9b93f18ae9ae?q=80&w=2070&auto=format&fit=crop",
                tags: ["Healthcare", "Patient Support", "COVID-19 Response", "Hospital"],
                year: "2020-2021",
            }
        ]
    },
    {
        title: "Projects",
        items: [
            {
                id: 20,
                title: "Predictive Sales Dashboard",
                description: "An interactive dashboard to forecast retail sales.",
                longDescription: "Developed a predictive sales forecasting model for a mock retail client using Python, Pandas, and Scikit-learn. The model utilizes historical sales data to predict future trends. The results are presented in an interactive dashboard built with Plotly Dash, allowing users to explore forecasts by product category and region.",
                imageUrl: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=2070&auto=format&fit=crop",
                tags: ["Python", "Machine Learning", "Data Visualization", "Forecasting"],
                year: "2024",
                link: "https://github.com/challanamuskan/sales-dashboard",
            },
            {
                id: 21,
                title: "Customer Segmentation Analysis",
                description: "Grouping customers based on purchasing behavior.",
                longDescription: "Performed an in-depth customer segmentation analysis using SQL to extract transaction data and R for K-Means clustering. Identified distinct customer personas, providing actionable insights for targeted marketing campaigns that could potentially increase engagement by 25%.",
                imageUrl: "https://images.unsplash.com/photo-1556740738-b6a63e27c4df?q=80&w=2070&auto=format&fit=crop",
                tags: ["R", "SQL", "Clustering", "Marketing Analytics"],
                year: "2023",
                link: "https://github.com/challanamuskan/customer-segmentation",
            },
            {
                id: 22,
                title: "AI Portfolio Assistant (Jerry)",
                description: "The voice-enabled chatbot on this website.",
                longDescription: "Designed and integrated 'Jerry', the AI assistant for this portfolio website, using the Gemini API. This project showcases practical application of large language models (LLMs) for creating interactive user experiences. The chatbot can answer questions about my skills and experience in both text and voice formats.",
                imageUrl: "https://images.unsplash.com/photo-1620712943543-95fc636a0342?q=80&w=2070&auto=format&fit=crop",
                tags: ["Generative AI", "Gemini API", "React", "TypeScript"],
                year: "2024",
                link: "https://github.com/challanamuskan/myflix-portfolio",
            }
        ]
    },
     {
        title: "Key Achievements",
        items: [
            {
                id: 17,
                title: "National Swimming Representation",
                description: "Represented India in freestyle swimming internationally.",
                longDescription: "Twice represented India in freestyle swimming at international competitions between 2014 and 2016, showcasing dedication, discipline, and peak physical performance on a global stage.",
                imageUrl: "https://images.unsplash.com/photo-1560272564-c83b66b17415?q=80&w=2070&auto=format&fit=crop",
                tags: ["Swimming", "India", "Freestyle", "Athlete"],
                year: "2014-2016",
                modalStyle: 'achievement',
            },
            {
                id: 18,
                title: "International Kathak Representation",
                description: "Represented India in Kathak dance on the world stage.",
                longDescription: "Twice represented India in the classical dance form of Kathak from 2012 to 2014, blending intricate footwork, expressive storytelling, and cultural heritage in international performances.",
                imageUrl: "https://images.unsplash.com/photo-1621335828751-84224571d072?q=80&w=1974&auto=format&fit=crop",
                tags: ["Kathak", "Dance", "India", "Cultural Arts"],
                year: "2012-2014",
                modalStyle: 'achievement',
            },
            {
                id: 19,
                title: "IIM Rohtak Coding Competition",
                description: "Secured 3rd place in a competitive coding round.",
                longDescription: "Achieved 3rd position in a high-pressure coding round organized by the prestigious Indian Institute of Management (IIM) Rohtak. This accomplishment highlights strong problem-solving abilities, algorithmic thinking, and proficiency in competitive programming.",
                imageUrl: "https://images.unsplash.com/photo-1542831371-29b0f74f9713?q=80&w=2070&auto=format&fit=crop",
                tags: ["Coding", "IIM Rohtak", "Competition", "Algorithms"],
                year: "2025",
                modalStyle: 'achievement',
            }
        ]
    },
    {
        title: "Certifications & Badges",
        items: [
            {
                id: 23,
                title: "Data Science & Analytics",
                description: "HP LIFE (HP Foundation)",
                longDescription: "This course provides knowledge on leading data science and analytics practices, methodologies, and tools. It examines the benefits and challenges of a data-driven approach for businesses and covers essential skills needed for a career in the field. The program explores how organizations leverage data for innovation, decision-making, and building strong customer relationships.",
                imageUrl: "https://images.unsplash.com/photo-1634712282210-2b7a3c35f3b5?q=80&w=2070&auto=format&fit=crop",
                tags: ["Data Science", "HP LIFE", "Analytics", "Business Intelligence"],
                year: "2025",
            },
            {
                id: 24,
                title: "AI for Business Professionals",
                description: "HP LIFE (HP Foundation)",
                longDescription: "This course equips professionals with the knowledge to leverage Artificial Intelligence (AI) for enhanced productivity, decision-making, and career growth. The training covers AI's role in business, the difference between standalone AI tools (like ChatGPT) and integrated features, how to craft effective prompts, and ethical AI use.",
                imageUrl: "https://images.unsplash.com/photo-1677756119517-756a188d2d94?q=80&w=2070&auto=format&fit=crop",
                tags: ["AI", "HP LIFE", "Business", "Productivity"],
                year: "2025",
            },
             {
                id: 25,
                title: "Enginow Coding Round",
                description: "Participation Certificate from Unstop.",
                longDescription: "Participation in an online, individual coding competition hosted on the Unstop platform. These rounds challenge participants to solve medium to hard-level programming questions and are evaluated based on test case accuracy and code efficiency.",
                imageUrl: "https://images.unsplash.com/photo-1515879218367-8466d910aaa4?q=80&w=2069&auto=format&fit=crop",
                tags: ["Coding", "Competition", "Unstop", "Algorithms"],
                year: "2025",
            },
            {
                id: 26,
                title: "ICT Quiz Competition",
                description: "Participation Certificate from ICT, Mumbai.",
                longDescription: "Participation in a Quiz Competition organized by the Institute of Chemical Technology, Mumbai on the occasion of World Pharmacist Day. Such quizzes typically test knowledge in pharmacy, healthcare, and the role of pharmacists in global health.",
                imageUrl: "https://images.unsplash.com/photo-1581093458791-9a6685c2e505?q=80&w=2070&auto=format&fit=crop",
                tags: ["Quiz", "Competition", "Healthcare", "Pharmacy"],
                year: "2025",
            },
            {
                id: 5,
                title: "Google Data Analytics",
                description: "Professional Certificate from Coursera.",
                longDescription: "Completed the Google Data Analytics Professional Certificate in August 2022. Mastered essential skills in data cleaning, processing, analyzing, and visualizing data, with a focus on practical application to real-world retail trends.",
                imageUrl: "https://images.unsplash.com/photo-1620712943543-95fc636a0342?q=80&w=2070&auto=format&fit=crop",
                tags: ["Data Analytics", "Coursera", "Data Visualization", "R"],
                year: "2022",
                link: "https://www.coursera.org/account/accomplishments/professional-cert/8Z9X6X8Z9X6X" // Replace with actual link
            },
            {
                id: 6,
                title: "Microsoft Excel for Business",
                description: "Business Analytics Certificate from edX.",
                longDescription: "Completed the Microsoft Excel for Business Analytics certificate on edX in June 2024. Focused on optimizing inventory scenarios and solving complex business problems with advanced Excel tools and formulas.",
                imageUrl: "https://images.unsplash.com/photo-1611262588024-d12430b98920?q=80&w=1974&auto=format&fit=crop",
                tags: ["Excel", "Business Analytics", "edX", "Inventory"],
                year: "2024",
            },
            {
                id: 7,
                title: "Cisco Networking Academy",
                description: "Multiple certifications in Data & Networking.",
                longDescription: "Achieved a wide range of certifications from the Cisco Networking Academy, including: Networking Basics, Data Analytics Essentials, Dashboarding Basics, Project Portfolio, Ethical Use of Data, SQL Basics, and Transforming Data with Excel.",
                imageUrl: "https://images.unsplash.com/photo-1593435713583-2effa2f6472f?q=80&w=2070&auto=format&fit=crop",
                tags: ["Cisco", "Data Analytics", "SQL", "Networking"],
                year: "2025",
            },
            {
                id: 15,
                title: "International Youth Math Challenge",
                description: "Final Round Qualifier.",
                longDescription: "Successfully qualified for and completed the final round of the International Youth Math Challenge, demonstrating exceptional problem-solving and mathematical reasoning skills in a competitive global environment.",
                imageUrl: "https://images.unsplash.com/photo-1509228468518-180dd4864904?q=80&w=2070&auto=format&fit=crop",
                tags: ["Mathematics", "IYMC", "Problem Solving", "Competition"],
                year: "2023",
            },
            {
                id: 16,
                title: "BRICS Mathematics Competition",
                description: "Stage 2 Completion Certificate.",
                longDescription: "Advanced to and successfully completed the second stage of the BRICS Mathematics Online Competition, tackling complex problems and showcasing a high level of mathematical proficiency among participants from Brazil, Russia, India, China, and South Africa.",
                imageUrl: "https://images.unsplash.com/photo-1453733190371-0a9bedd82893?q=80&w=2070&auto=format&fit=crop",
                tags: ["Mathematics", "BRICS", "Competition", "Advanced Math"],
                year: "2024",
            }
        ]
    },
    {
        title: "Education",
        items: [
            {
                id: 13,
                title: "Torrens University, Adelaide",
                description: "Bachelor of Business Information Systems",
                longDescription: "Led a 4-person capstone team analysing 50+ consumer surveys, building Excel regression models that validated hypotheses and inspired a 15-slide PowerPoint presentation. Proposed solutions projecting 18% efficiency gains for a retail client. Mastered advanced statistics, predictive modelling, and data programming (Python, R, SPSS) to simulate market trends.",
                imageUrl: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?q=80&w=2072&auto=format&fit=crop",
                tags: ["Data Programming", "Predictive Modelling", "Capstone Project"],
                year: "Expected 2026",
            },
            {
                id: 14,
                title: "Kenbridge School, Kota",
                description: "High School (Top 10%)",
                longDescription: "Graduated in the top 10% in Mathematics and Economics, laying a solid foundation for data-driven decisions. Captained the debate club, turning shy discussions into confident client-facing pitches that won regional rounds.",
                imageUrl: "https://images.unsplash.com/photo-1523050854058-8df90110c9f1?q=80&w=2070&auto=format&fit=crop",
                tags: ["Mathematics", "Economics", "Debate Club Captain", "Leadership"],
                year: "2020",
            },
        ]
    },
    {
        title: "Skills",
        items: [
            { id: 9, title: "Analytical & Technical", description: "Advanced Excel, Python/R, SPSS, SQL, AI, Hadoop.", longDescription: "Advanced Excel (VLOOKUP, pivot tables, forecasting), Python/R for data visualization, SPSS for hypothesis testing, SQL for database queries, AI applications (generative models), data ethics, and Hadoop basics.", imageUrl: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=2070&auto=format&fit=crop", tags: [], year: "Core Skill" },
            { id: 10, title: "Communication", description: "Presentations, multicultural teams, native English.", longDescription: "Expertise in creating and delivering compelling PowerPoint presentations. Skilled in tailoring verbal and written communication styles for diverse, multicultural teams. Native English fluency.", imageUrl: "https://images.unsplash.com/photo-1557804506-669a67965ba0?q=80&w=1974&auto=format&fit=crop", tags: [], year: "Core Skill" },
            { id: 11, title: "Professional Acumen", description: "Time management, quick learning, travel-ready.", longDescription: "Demonstrated ability in autonomous time management and quick learning in high-stakes roles. Ready to travel and adaptable with flexible scheduling to meet project demands.", imageUrl: "https://images.unsplash.com/photo-1521791136064-7986c2920216?q=80&w=2070&auto=format&fit=crop", tags: [], year: "Core Skill" },
            { id: 12, title: "Leadership & Networking", description: "UniSA Business Analytics Society, Virtual Insight Program.", longDescription: "Active Member of UniSA Business Analytics Society, sharing retail insights and volunteering for AI in Retail lecture. Participant in the Torrens University x Virtual Insight Program, networking with consultants and sharpening problem-solving.", imageUrl: "https://images.unsplash.com/photo-1587573089734-09cb69c0f2b4?q=80&w=2070&auto=format&fit=crop", tags: [], year: "Core Skill" },
        ]
    }
];